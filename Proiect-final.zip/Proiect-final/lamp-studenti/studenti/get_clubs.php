<?php
require 'db.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id_club, nume FROM Cluburi ORDER BY nume ASC");
    $clubs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($clubs);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>