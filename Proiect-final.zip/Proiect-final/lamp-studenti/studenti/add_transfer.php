<?php
session_start();
require 'db.php';

if (!isset($_SESSION['loggedin'])) {
    echo json_encode(['success' => false, 'message' => 'Neautorizat']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Inserăm Jucătorul cu ID-ul manual
    $stmtJ = $pdo->prepare("INSERT INTO Jucatori (id_jucator, nume, varsta, pozitie, nationalitate, valoare_piata, data_nastere) VALUES (?, ?, ?, ?, ?, ?, CURDATE())");
    $stmtJ->execute([$_POST['id_jucator'], $_POST['nume'], $_POST['varsta'], $_POST['pozitie'], $_POST['nat'], $_POST['valoare']]);

    // 2. Inserăm Transferul cu ID-ul manual
    // id_jucator trebuie să fie același cu cel de mai sus pentru a respecta Foreign Key
    $stmtT = $pdo->prepare("INSERT INTO Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer, data_transfer) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmtT->execute([$_POST['id_transfer'], $_POST['id_jucator'], $_POST['id_club_vechi'], $_POST['id_club_nou'], $_POST['suma']]);

    // 3. Inserăm Contractul cu ID-ul manual
    $stmtC = $pdo->prepare("INSERT INTO Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (?, ?, ?, ?, CURDATE(), ?, 0)");
    $stmtC->execute([$_POST['id_contract'], $_POST['id_jucator'], $_POST['id_club_nou'], $_POST['salariu'], $_POST['data_sfarsit']]);

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => "Eroare SQL: " . $e->getMessage()]);
}
?>