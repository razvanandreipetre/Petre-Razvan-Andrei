create table Agent
(
    id_agent int          not null
        primary key,
    id_user  int          not null,
    nume     varchar(100) not null,
    email    varchar(100) not null,
    telefon  bigint       not null,
    constraint Agent_ibfk_1
        foreign key (id_user) references User (id)
);

create index id_user
    on Agent (id_user);

INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (1, 1, 'Agent1', 'agent1@email.com', 744870593);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (2, 2, 'Agent2', 'agent2@email.com', 721184309);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (3, 3, 'Agent3', 'agent3@email.com', 771309768);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (4, 4, 'Agent4', 'agent4@email.com', 792995917);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (5, 5, 'Agent5', 'agent5@email.com', 751050286);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (6, 6, 'Agent6', 'agent6@email.com', 776263683);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (7, 7, 'Agent7', 'agent7@email.com', 728167564);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (8, 8, 'Agent8', 'agent8@email.com', 712046773);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (9, 9, 'Agent9', 'agent9@email.com', 775731175);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (10, 10, 'Agent10', 'agent10@email.com', 742515564);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (11, 11, 'Agent11', 'agent11@email.com', 785384297);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (12, 12, 'Agent12', 'agent12@email.com', 799374799);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (13, 13, 'Agent13', 'agent13@email.com', 740721109);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (14, 14, 'Agent14', 'agent14@email.com', 705481149);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (15, 15, 'Agent15', 'agent15@email.com', 705242420);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (16, 16, 'Agent16', 'agent16@email.com', 709768660);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (17, 17, 'Agent17', 'agent17@email.com', 733116041);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (18, 18, 'Agent18', 'agent18@email.com', 736274231);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (19, 19, 'Agent19', 'agent19@email.com', 782023033);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (20, 20, 'Agent20', 'agent20@email.com', 701292481);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (21, 21, 'Agent21', 'agent21@email.com', 760393307);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (22, 22, 'Agent22', 'agent22@email.com', 798089096);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (23, 23, 'Agent23', 'agent23@email.com', 709265567);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (24, 24, 'Agent24', 'agent24@email.com', 752060548);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (25, 25, 'Agent25', 'agent25@email.com', 732506042);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (26, 26, 'Agent26', 'agent26@email.com', 706348572);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (27, 27, 'Agent27', 'agent27@email.com', 734224735);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (28, 28, 'Agent28', 'agent28@email.com', 752077963);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (29, 29, 'Agent29', 'agent29@email.com', 757715614);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (30, 30, 'Agent30', 'agent30@email.com', 732344187);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (31, 31, 'Agent31', 'agent31@email.com', 788574094);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (32, 32, 'Agent32', 'agent32@email.com', 745837917);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (33, 33, 'Agent33', 'agent33@email.com', 763467304);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (34, 34, 'Agent34', 'agent34@email.com', 779822773);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (35, 35, 'Agent35', 'agent35@email.com', 708711958);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (36, 36, 'Agent36', 'agent36@email.com', 704091475);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (37, 37, 'Agent37', 'agent37@email.com', 794321504);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (38, 38, 'Agent38', 'agent38@email.com', 759333101);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (39, 39, 'Agent39', 'agent39@email.com', 713700996);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (40, 40, 'Agent40', 'agent40@email.com', 790505680);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (41, 41, 'Agent41', 'agent41@email.com', 711425419);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (42, 42, 'Agent42', 'agent42@email.com', 785610057);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (43, 43, 'Agent43', 'agent43@email.com', 793774033);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (44, 44, 'Agent44', 'agent44@email.com', 712040000);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (45, 45, 'Agent45', 'agent45@email.com', 778877904);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (46, 46, 'Agent46', 'agent46@email.com', 758269523);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (47, 47, 'Agent47', 'agent47@email.com', 754713907);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (48, 48, 'Agent48', 'agent48@email.com', 798760970);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (49, 49, 'Agent49', 'agent49@email.com', 729663137);
INSERT INTO studenti.Agent (id_agent, id_user, nume, email, telefon) VALUES (50, 50, 'Agent50', 'agent50@email.com', 752032776);
