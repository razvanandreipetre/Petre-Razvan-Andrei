create table Jucatori
(
    id_jucator    int          not null
        primary key,
    nume          varchar(100) not null,
    data_nastere  date         not null,
    valoare_piata float        not null,
    varsta        int          not null,
    pozitie       varchar(50)  not null,
    nationalitate varchar(50)  not null
);

INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (1, 'Jucator1', '2005-05-21', 97.93, 23, 'Portar', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (2, 'Jucator2', '1996-05-21', 61.37, 30, 'Atacant', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (3, 'Jucator3', '1997-05-21', 54.91, 26, 'Portar', 'Argentina');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (4, 'Jucator4', '2005-05-21', 3.13, 27, 'Fundas', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (5, 'Jucator5', '2002-05-21', 36.48, 27, 'Portar', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (6, 'Jucator6', '1993-05-21', 40.91, 21, 'Portar', 'Brazilia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (7, 'Jucator7', '2001-05-21', 47.87, 18, 'Atacant', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (8, 'Jucator8', '2003-05-21', 30.82, 28, 'Mijlocas', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (9, 'Jucator9', '1994-05-21', 29.97, 30, 'Mijlocas', 'Anglia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (10, 'Jucator10', '2003-05-21', 36.99, 32, 'Portar', 'Franta');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (11, 'Jucator11', '2002-05-21', 17.61, 27, 'Atacant', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (12, 'Jucator12', '1996-05-21', 12.08, 21, 'Mijlocas', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (13, 'Jucator13', '2000-05-21', 27.85, 30, 'Atacant', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (14, 'Jucator14', '1996-05-21', 80.37, 27, 'Fundas', 'Franta');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (15, 'Jucator15', '2007-05-21', 66.02, 20, 'Atacant', 'Olanda');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (16, 'Jucator16', '2005-05-21', 87.91, 32, 'Mijlocas', 'Germania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (17, 'Jucator17', '1998-05-21', 24.22, 23, 'Portar', 'Germania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (18, 'Jucator18', '1999-05-21', 65.52, 27, 'Portar', 'Franta');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (19, 'Jucator19', '1999-05-21', 35.66, 19, 'Portar', 'Anglia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (20, 'Jucator20', '2005-05-21', 8.52, 31, 'Mijlocas', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (21, 'Jucator21', '1999-05-21', 89.8, 29, 'Portar', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (22, 'Jucator22', '2004-05-21', 65.82, 25, 'Portar', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (23, 'Jucator23', '1994-05-21', 76.6, 18, 'Fundas', 'Argentina');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (24, 'Jucator24', '2001-05-21', 21.82, 29, 'Atacant', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (25, 'Jucator25', '1999-05-21', 62, 23, 'Fundas', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (26, 'Jucator26', '1994-05-21', 80.21, 23, 'Atacant', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (27, 'Jucator27', '1995-05-21', 35.36, 22, 'Fundas', 'Germania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (28, 'Jucator28', '1997-05-21', 58.93, 30, 'Fundas', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (29, 'Jucator29', '2007-05-21', 71.14, 25, 'Mijlocas', 'Spania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (30, 'Jucator30', '2001-05-21', 82.29, 31, 'Fundas', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (31, 'Jucator31', '2003-05-21', 99.5, 19, 'Portar', 'Brazilia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (32, 'Jucator32', '2002-05-21', 4.91, 18, 'Mijlocas', 'Argentina');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (33, 'Jucator33', '2006-05-21', 45.11, 31, 'Portar', 'Romania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (34, 'Jucator34', '2000-05-21', 67.26, 29, 'Portar', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (35, 'Jucator35', '2005-05-21', 95.28, 22, 'Atacant', 'Italia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (36, 'Jucator36', '2006-05-21', 5.64, 30, 'Mijlocas', 'Spania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (37, 'Jucator37', '2004-05-21', 73.01, 32, 'Portar', 'Spania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (38, 'Jucator38', '2005-05-21', 42.6, 28, 'Mijlocas', 'Brazilia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (39, 'Jucator39', '1999-05-21', 11.76, 30, 'Portar', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (40, 'Jucator40', '2001-05-21', 19.85, 27, 'Atacant', 'Franta');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (41, 'Jucator41', '2005-05-21', 46.24, 31, 'Mijlocas', 'Anglia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (42, 'Jucator42', '1997-05-21', 75.25, 28, 'Portar', 'Portugalia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (43, 'Jucator43', '1996-05-21', 19.1, 27, 'Portar', 'Olanda');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (44, 'Jucator44', '2007-05-21', 38.51, 28, 'Mijlocas', 'Argentina');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (45, 'Jucator45', '2007-05-21', 51.77, 26, 'Fundas', 'Olanda');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (46, 'Jucator46', '1996-05-21', 40.59, 28, 'Portar', 'Brazilia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (47, 'Jucator47', '2003-05-21', 21.12, 20, 'Portar', 'Anglia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (48, 'Jucator48', '2001-05-21', 64.89, 32, 'Portar', 'Spania');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (49, 'Jucator49', '1999-05-21', 48.74, 29, 'Atacant', 'Brazilia');
INSERT INTO studenti.Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate) VALUES (50, 'Jucator50', '1997-05-21', 53.31, 25, 'Fundas', 'Franta');
