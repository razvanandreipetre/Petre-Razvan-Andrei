create table Cluburi
(
    id_club int          not null
        primary key,
    nume    varchar(100) not null,
    tara    varchar(50)  not null
);

INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (1, 'Club1', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (2, 'Club2', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (3, 'Club3', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (4, 'Club4', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (5, 'Club5', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (6, 'Club6', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (7, 'Club7', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (8, 'Club8', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (9, 'Club9', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (10, 'Club10', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (11, 'Club11', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (12, 'Club12', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (13, 'Club13', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (14, 'Club14', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (15, 'Club15', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (16, 'Club16', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (17, 'Club17', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (18, 'Club18', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (19, 'Club19', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (20, 'Club20', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (21, 'Club21', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (22, 'Club22', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (23, 'Club23', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (24, 'Club24', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (25, 'Club25', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (26, 'Club26', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (27, 'Club27', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (28, 'Club28', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (29, 'Club29', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (30, 'Club30', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (31, 'Club31', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (32, 'Club32', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (33, 'Club33', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (34, 'Club34', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (35, 'Club35', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (36, 'Club36', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (37, 'Club37', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (38, 'Club38', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (39, 'Club39', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (40, 'Club40', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (41, 'Club41', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (42, 'Club42', 'Anglia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (43, 'Club43', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (44, 'Club44', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (45, 'Club45', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (46, 'Club46', 'Italia');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (47, 'Club47', 'Franta');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (48, 'Club48', 'Germania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (49, 'Club49', 'Spania');
INSERT INTO studenti.Cluburi (id_club, nume, tara) VALUES (50, 'Club50', 'Italia');
