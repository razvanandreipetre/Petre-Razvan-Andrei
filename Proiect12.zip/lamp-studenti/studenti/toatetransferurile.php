<?php
require_once '../db.php'; 
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // ATENȚIE: Interogarea de mai jos folosește ID-uri ca placeholder. 
    // Pentru a afișa nume reale (JUCATOR, ULTIMA ECHIPA, TRANSFER LA), 
    // tabelele Jucatori și Cluburi sunt esențiale și trebuie populate.

    $sql = "SELECT 
                id_jucator AS jucator_id,  
                id_club_actual AS ultima_echipa_id,  
                id_club_destinatie AS transfer_la_id,  
                suma_transfer,
                'N/A' AS contract,
                'N/A' AS data
            FROM Transferuri 
            ORDER BY id_transfer DESC"; 

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $transferuri = $stmt->fetchAll();
        
        // 3. Trimite răspuns JSON înapoi la browser
        echo json_encode([
            "status" => "warning", 
            "transferuri" => $transferuri, 
            "message" => "Tabelele Jucatori și Cluburi nu sunt disponibile, se afișează ID-uri." 
        ]);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Eroare BD la extragerea transferurilor: " . $e->getMessage()]);
    }

} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Metodă nepermisă."]);
}
?>