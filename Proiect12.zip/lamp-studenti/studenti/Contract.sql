create table Contract
(
    id_contract      int   not null
        primary key,
    id_jucator       int   not null,
    id_club          int   not null,
    salariu          int   not null,
    data_start       date  not null,
    data_sfarsit     date  not null,
    clauza_reziliere float not null,
    constraint Contract_ibfk_1
        foreign key (id_jucator) references Jucatori (id_jucator),
    constraint Contract_ibfk_2
        foreign key (id_club) references Cluburi (id_club)
);

create index id_club
    on Contract (id_club);

create index id_jucator
    on Contract (id_jucator);

create index idx_salariu
    on Contract (salariu);

INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (1, 1, 36, 24954, '2025-05-21', '2030-05-21', 3.74);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (2, 2, 41, 9571, '2025-05-21', '2029-05-21', 9.76);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (3, 3, 13, 16756, '2025-05-21', '2027-05-21', 3.84);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (4, 4, 40, 7224, '2025-05-21', '2026-05-21', 6.55);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (5, 5, 12, 15716, '2025-05-21', '2030-05-21', 2.9);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (6, 6, 4, 20618, '2025-05-21', '2029-05-21', 2.31);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (7, 7, 29, 14083, '2025-05-21', '2028-05-21', 5.53);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (8, 8, 29, 15404, '2025-05-21', '2030-05-21', 9.07);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (9, 9, 21, 17845, '2025-05-21', '2030-05-21', 10.44);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (10, 10, 40, 8170, '2025-05-21', '2027-05-21', 6.15);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (11, 11, 20, 12157, '2025-05-21', '2029-05-21', 2.65);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (12, 12, 45, 23314, '2025-05-21', '2030-05-21', 10.13);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (13, 13, 39, 6983, '2025-05-21', '2026-05-21', 7.71);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (14, 14, 39, 21979, '2025-05-21', '2030-05-21', 1.95);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (15, 15, 35, 8166, '2025-05-21', '2029-05-21', 2.56);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (16, 16, 31, 15841, '2025-05-21', '2030-05-21', 9.94);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (17, 17, 38, 7163, '2025-05-21', '2027-05-21', 1.09);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (18, 18, 13, 8816, '2025-05-21', '2027-05-21', 6.48);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (19, 19, 4, 18933, '2025-05-21', '2027-05-21', 4.04);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (20, 20, 35, 14986, '2025-05-21', '2028-05-21', 8.54);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (21, 21, 22, 21819, '2025-05-21', '2030-05-21', 2.88);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (22, 22, 6, 5051, '2025-05-21', '2029-05-21', 4.57);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (23, 23, 39, 20367, '2025-05-21', '2028-05-21', 4.82);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (24, 24, 15, 11800, '2025-05-21', '2030-05-21', 1.23);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (25, 25, 35, 12715, '2025-05-21', '2030-05-21', 2.18);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (26, 26, 2, 20463, '2025-05-21', '2029-05-21', 7.27);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (27, 27, 39, 24072, '2025-05-21', '2028-05-21', 5.77);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (28, 28, 50, 14469, '2025-05-21', '2028-05-21', 8.06);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (29, 29, 13, 8017, '2025-05-21', '2030-05-21', 6.13);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (30, 30, 30, 12961, '2025-05-21', '2027-05-21', 10.42);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (31, 31, 2, 11362, '2025-05-21', '2028-05-21', 6.65);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (32, 32, 16, 22595, '2025-05-21', '2028-05-21', 7.27);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (33, 33, 39, 5013, '2025-05-21', '2029-05-21', 4.67);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (34, 34, 41, 24380, '2025-05-21', '2028-05-21', 2.08);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (35, 35, 17, 11541, '2025-05-21', '2029-05-21', 3.44);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (36, 36, 15, 18869, '2025-05-21', '2029-05-21', 10.8);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (37, 37, 4, 12536, '2025-05-21', '2029-05-21', 4.41);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (38, 38, 32, 6624, '2025-05-21', '2028-05-21', 5.78);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (39, 39, 38, 11871, '2025-05-21', '2028-05-21', 3.3);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (40, 40, 40, 10368, '2025-05-21', '2030-05-21', 1.34);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (41, 41, 14, 9630, '2025-05-21', '2027-05-21', 1.92);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (42, 42, 20, 18459, '2025-05-21', '2026-05-21', 10.54);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (43, 43, 10, 6460, '2025-05-21', '2030-05-21', 9);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (44, 44, 30, 15740, '2025-05-21', '2030-05-21', 1.07);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (45, 45, 14, 10864, '2025-05-21', '2029-05-21', 6.11);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (46, 46, 27, 6487, '2025-05-21', '2030-05-21', 9.12);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (47, 47, 32, 20048, '2025-05-21', '2030-05-21', 10.91);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (48, 48, 21, 6060, '2025-05-21', '2026-05-21', 1.91);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (49, 49, 16, 9980, '2025-05-21', '2027-05-21', 10.14);
INSERT INTO studenti.Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere) VALUES (50, 50, 29, 7309, '2025-05-21', '2030-05-21', 10.73);
