create table Transferuri
(
    id_transfer        int   not null
        primary key,
    id_jucator         int   not null,
    id_club_actual     int   not null,
    id_club_destinatie int   not null,
    suma_transfer      float not null,
    constraint Transferuri_ibfk_1
        foreign key (id_jucator) references Jucatori (id_jucator),
    constraint Transferuri_ibfk_2
        foreign key (id_club_actual) references Cluburi (id_club),
    constraint Transferuri_ibfk_3
        foreign key (id_club_destinatie) references Cluburi (id_club)
);

create index id_club_actual
    on Transferuri (id_club_actual);

create index id_club_destinatie
    on Transferuri (id_club_destinatie);

create index id_jucator
    on Transferuri (id_jucator);

INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (1, 20, 14, 22, 59.87);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (2, 39, 41, 12, 17);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (3, 10, 25, 47, 21.42);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (4, 17, 22, 27, 10.21);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (5, 42, 24, 3, 6.24);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (6, 33, 38, 29, 53.16);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (7, 28, 33, 36, 65.9);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (8, 15, 30, 1, 38.66);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (9, 8, 2, 3, 61.8);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (10, 33, 30, 4, 3.64);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (11, 22, 9, 40, 80.86);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (12, 10, 35, 3, 80.61);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (13, 4, 21, 34, 38.55);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (14, 49, 34, 10, 30.97);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (15, 3, 29, 48, 39.2);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (16, 9, 39, 35, 75.08);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (17, 27, 11, 42, 15.57);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (18, 48, 8, 14, 96.87);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (19, 43, 46, 37, 6.24);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (20, 19, 37, 26, 31.24);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (21, 19, 21, 6, 50.15);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (22, 20, 18, 15, 8.54);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (23, 26, 11, 42, 5.61);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (24, 1, 36, 22, 73.36);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (25, 32, 31, 45, 47.29);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (26, 25, 22, 38, 17.68);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (27, 39, 19, 20, 73.08);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (28, 26, 15, 14, 74.42);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (29, 49, 7, 24, 46.24);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (30, 27, 17, 16, 72.72);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (31, 20, 1, 45, 34.75);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (32, 41, 25, 23, 66.73);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (33, 13, 44, 19, 13.67);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (34, 35, 45, 4, 21.59);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (35, 23, 49, 14, 38.91);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (36, 46, 29, 37, 35.48);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (37, 7, 1, 2, 57.49);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (38, 41, 22, 21, 82.84);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (39, 4, 33, 41, 96.21);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (40, 28, 27, 42, 29);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (41, 44, 37, 41, 94.11);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (42, 39, 2, 19, 70.22);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (43, 25, 9, 41, 3);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (44, 43, 33, 8, 80.21);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (45, 50, 21, 33, 7.73);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (46, 25, 18, 26, 92.92);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (47, 17, 8, 48, 84.94);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (48, 16, 9, 19, 48.42);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (49, 8, 22, 35, 68.25);
INSERT INTO studenti.Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer) VALUES (50, 22, 47, 33, 25.19);
