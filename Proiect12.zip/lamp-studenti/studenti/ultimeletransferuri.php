<?php
require_once '../db.php'; 
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // Luăm primele 10 transferuri (cele mai mari ID-uri)
    $sql = "SELECT 
                id_jucator AS jucator_id,  
                id_club_actual AS ultima_echipa_id,  
                id_club_destinatie AS transfer_la_id,  
                suma_transfer,
                'N/A' AS contract,
                'N/A' AS data
            FROM Transferuri 
            ORDER BY id_transfer DESC 
            LIMIT 10"; 

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $transferuri = $stmt->fetchAll();
        
        echo json_encode([
            "status" => "warning", 
            "transferuri" => $transferuri, 
            "message" => "Tabelele Jucatori și Cluburi nu sunt disponibile, se afișează ID-uri." 
        ]);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Eroare BD la extragerea ultimelor transferuri: " . $e->getMessage()]);
    }

} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Metodă nepermisă."]);
}
?>