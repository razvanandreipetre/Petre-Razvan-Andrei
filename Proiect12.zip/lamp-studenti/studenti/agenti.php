<?php
// Include fișierul de conexiune PDO
require_once '../db.php'; 

// 1. Setăm antetul pentru răspuns JSON
header('Content-Type: application/json');

// 2. Procesăm cererea (doar GET este acceptat pentru preluare date)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // Interogare SQL: Selectăm Numele Agentului și datele de Contact
    $sql = "SELECT 
                nume, 
                CONCAT('Email: ', email) AS email, 
                CONCAT('Tel: ', telefon) AS telefon 
            FROM Agent 
            ORDER BY nume ASC";

    try {
        // Prepară și execută interogarea (PDO)
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $agenti = $stmt->fetchAll();

        // 3. Trimite răspuns JSON înapoi la browser
        echo json_encode(["status" => "ok", "agenti" => $agenti]); //
        
    } catch (PDOException $e) {
        http_response_code(500);
        // Trimite un răspuns JSON de eroare
        echo json_encode(["status" => "error", "message" => "Eroare BD la extragerea agentilor: " . $e->getMessage()]);
    }

} else {
    // Metodă nepermisă
    http_response_code(405); 
    echo json_encode(["status" => "error", "message" => "Metodă nepermisă. Folositi metoda GET."]);
}
?>