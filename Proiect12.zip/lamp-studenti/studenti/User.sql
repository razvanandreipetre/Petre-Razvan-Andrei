create table User
(
    id       int          not null
        primary key,
    username varchar(100) not null,
    parola   varchar(100) not null
);

INSERT INTO studenti.User (id, username, parola) VALUES (1, 'user1', 'pass1');
INSERT INTO studenti.User (id, username, parola) VALUES (2, 'user2', 'pass2');
INSERT INTO studenti.User (id, username, parola) VALUES (3, 'user3', 'pass3');
INSERT INTO studenti.User (id, username, parola) VALUES (4, 'user4', 'pass4');
INSERT INTO studenti.User (id, username, parola) VALUES (5, 'user5', 'pass5');
INSERT INTO studenti.User (id, username, parola) VALUES (6, 'user6', 'pass6');
INSERT INTO studenti.User (id, username, parola) VALUES (7, 'user7', 'pass7');
INSERT INTO studenti.User (id, username, parola) VALUES (8, 'user8', 'pass8');
INSERT INTO studenti.User (id, username, parola) VALUES (9, 'user9', 'pass9');
INSERT INTO studenti.User (id, username, parola) VALUES (10, 'user10', 'pass10');
INSERT INTO studenti.User (id, username, parola) VALUES (11, 'user11', 'pass11');
INSERT INTO studenti.User (id, username, parola) VALUES (12, 'user12', 'pass12');
INSERT INTO studenti.User (id, username, parola) VALUES (13, 'user13', 'pass13');
INSERT INTO studenti.User (id, username, parola) VALUES (14, 'user14', 'pass14');
INSERT INTO studenti.User (id, username, parola) VALUES (15, 'user15', 'pass15');
INSERT INTO studenti.User (id, username, parola) VALUES (16, 'user16', 'pass16');
INSERT INTO studenti.User (id, username, parola) VALUES (17, 'user17', 'pass17');
INSERT INTO studenti.User (id, username, parola) VALUES (18, 'user18', 'pass18');
INSERT INTO studenti.User (id, username, parola) VALUES (19, 'user19', 'pass19');
INSERT INTO studenti.User (id, username, parola) VALUES (20, 'user20', 'pass20');
INSERT INTO studenti.User (id, username, parola) VALUES (21, 'user21', 'pass21');
INSERT INTO studenti.User (id, username, parola) VALUES (22, 'user22', 'pass22');
INSERT INTO studenti.User (id, username, parola) VALUES (23, 'user23', 'pass23');
INSERT INTO studenti.User (id, username, parola) VALUES (24, 'user24', 'pass24');
INSERT INTO studenti.User (id, username, parola) VALUES (25, 'user25', 'pass25');
INSERT INTO studenti.User (id, username, parola) VALUES (26, 'user26', 'pass26');
INSERT INTO studenti.User (id, username, parola) VALUES (27, 'user27', 'pass27');
INSERT INTO studenti.User (id, username, parola) VALUES (28, 'user28', 'pass28');
INSERT INTO studenti.User (id, username, parola) VALUES (29, 'user29', 'pass29');
INSERT INTO studenti.User (id, username, parola) VALUES (30, 'user30', 'pass30');
INSERT INTO studenti.User (id, username, parola) VALUES (31, 'user31', 'pass31');
INSERT INTO studenti.User (id, username, parola) VALUES (32, 'user32', 'pass32');
INSERT INTO studenti.User (id, username, parola) VALUES (33, 'user33', 'pass33');
INSERT INTO studenti.User (id, username, parola) VALUES (34, 'user34', 'pass34');
INSERT INTO studenti.User (id, username, parola) VALUES (35, 'user35', 'pass35');
INSERT INTO studenti.User (id, username, parola) VALUES (36, 'user36', 'pass36');
INSERT INTO studenti.User (id, username, parola) VALUES (37, 'user37', 'pass37');
INSERT INTO studenti.User (id, username, parola) VALUES (38, 'user38', 'pass38');
INSERT INTO studenti.User (id, username, parola) VALUES (39, 'user39', 'pass39');
INSERT INTO studenti.User (id, username, parola) VALUES (40, 'user40', 'pass40');
INSERT INTO studenti.User (id, username, parola) VALUES (41, 'user41', 'pass41');
INSERT INTO studenti.User (id, username, parola) VALUES (42, 'user42', 'pass42');
INSERT INTO studenti.User (id, username, parola) VALUES (43, 'user43', 'pass43');
INSERT INTO studenti.User (id, username, parola) VALUES (44, 'user44', 'pass44');
INSERT INTO studenti.User (id, username, parola) VALUES (45, 'user45', 'pass45');
INSERT INTO studenti.User (id, username, parola) VALUES (46, 'user46', 'pass46');
INSERT INTO studenti.User (id, username, parola) VALUES (47, 'user47', 'pass47');
INSERT INTO studenti.User (id, username, parola) VALUES (48, 'user48', 'pass48');
INSERT INTO studenti.User (id, username, parola) VALUES (49, 'user49', 'pass49');
INSERT INTO studenti.User (id, username, parola) VALUES (50, 'user50', 'pass50');