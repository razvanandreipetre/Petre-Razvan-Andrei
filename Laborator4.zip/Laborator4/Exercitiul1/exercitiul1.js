document.addEventListener('DOMContentLoaded', () => {
    const inputActivitate = document.getElementById('inputActivitate');
    const btnAdauga = document.getElementById('btnAdauga');
    const listaActivitati = document.getElementById('listaActivitati');

    const numeLuni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", 
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];
    btnAdauga.addEventListener('click', () => {
        const textActivitate = inputActivitate.value.trim();

        if (textActivitate !== "") {
            
            const newLi = document.createElement('li');
            
            const dataCurenta = new Date();
            
            const ziua = dataCurenta.getDate(); 
            
            const luna = numeLuni[dataCurenta.getMonth()]; 
           
            const an = dataCurenta.getFullYear();
            const textData = `${ziua} ${luna} ${an}`;
            
            newLi.innerHTML = `
                <span>Activitate - adăugată la ${textData}: <strong>${textActivitate}</strong></span>
            `;

            listaActivitati.appendChild(newLi);

            inputActivitate.value = ''; 
        } else {
            alert('Vă rugăm introduceți o activitate!');
        }
    });
});