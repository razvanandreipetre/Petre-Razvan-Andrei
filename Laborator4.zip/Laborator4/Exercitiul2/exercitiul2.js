document.addEventListener('DOMContentLoaded', () => {
    const detaliiContainer = document.getElementById('detalii');
    const btnDetalii = document.getElementById('btnDetalii');
    const dataProdusSpan = document.getElementById('dataProdus');

    detaliiContainer.classList.add('ascuns');

    const numeLuni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", 
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

    const dataCurenta = new Date();
    
    const ziua = dataCurenta.getDate(); 
    const lunaText = numeLuni[dataCurenta.getMonth()]; 
    const an = dataCurenta.getFullYear();
    
    dataProdusSpan.textContent = `${ziua} ${lunaText} ${an}`;


    btnDetalii.addEventListener('click', () => {
        
        detaliiContainer.classList.toggle('ascuns');

        if (detaliiContainer.classList.contains('ascuns')) {
            btnDetalii.textContent = 'Afișează detalii';
        } else {
            btnDetalii.textContent = 'Ascunde detalii';
        }
    });
});