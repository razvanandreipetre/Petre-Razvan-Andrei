<?php
// get_agenti.php

// 1. Includem fișierul tău de conectare care conține deja setările corecte pentru Docker
require 'db.php';

try {
    // 2. Pregătim interogarea (folosim PDO pentru că asta e în db.php)
    $sql = "SELECT nume, email, telefon FROM Agent";
    $stmt = $pdo->query($sql);

    // 3. Extragem datele
    $agenti = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Returnăm datele în format JSON către HTML
    header('Content-Type: application/json');
    echo json_encode($agenti);

} catch (Exception $e) {
    // În caz de eroare, trimitem un mesaj clar
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
?>