<?php
session_start();
require 'db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['number1'] ?? '';
    $username = $_POST['text1'] ?? '';
    $password = $_POST['password1'] ?? '';

    if (empty($id) || empty($username) || empty($password)) {
        echo "<script>alert('Te rog completează toate câmpurile!'); window.location.href='login.html';</script>";
        exit;
    }

    try {
        $sql = "SELECT * FROM User WHERE id = :id AND username = :username AND parola = :parola";
        $stmt = $pdo->prepare($sql);
        
        $stmt->execute([
            ':id' => $id,
            ':username' => $username,
            ':parola' => $password
        ]);

        $user = $stmt->fetch();

        if ($user) {
            // Login cu succes
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user['username'];
            header("Location: interfata.html");
            exit;
        } else {
            // Login eșuat - trimitem înapoi cu eroare
            header("Location: login.html?eroare=1");
            exit;
        }
    } catch (Exception $e) {
        echo "Eroare server: " . $e->getMessage();
    }
}
?>