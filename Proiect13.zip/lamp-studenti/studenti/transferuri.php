<?php
require_once 'db.php'; 

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    $sql = "
        SELECT 
            j.nume AS nume_jucator,
            j.pozitie,
            j.nationalitate,
            j.varsta,
            j.valoare_piata,
            a.nume AS nume_agent,    -- PRELUĂM NUMELE AGENTULUI
            a.email AS email_agent,  -- PRELUĂM ȘI EMAILUL (OPȚIONAL, DACĂ VREI TOOLTIP)
            c_vechi.nume AS club_vechi,
            c_nou.nume AS club_nou,
            t.suma_transfer,
            co.salariu,
            co.data_sfarsit AS data_contract,
            t.data_transfer
        FROM Transferuri t
        JOIN Jucatori j ON t.id_jucator = j.id_jucator
        -- AICI ESTE LEGĂTURA NOULĂ:
        LEFT JOIN Agent a ON j.id_agent = a.id_agent 
        JOIN Cluburi c_vechi ON t.id_club_actual = c_vechi.id_club
        JOIN Cluburi c_nou ON t.id_club_destinatie = c_nou.id_club
        LEFT JOIN Contract co ON (t.id_jucator = co.id_jucator AND t.id_club_destinatie = co.id_club)
        ORDER BY t.data_transfer DESC
    ";

    $stmt = $pdo->query($sql);
    $data = $stmt->fetchAll();
    echo json_encode($data);

} catch (PDOException $e) {
    echo json_encode(["error" => "Eroare SQL: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["error" => "Eroare Generală: " . $e->getMessage()]);
}
?>