<?php
session_start();
// Golim toate variabilele de sesiune
$_SESSION = array();
// Distrugem sesiunea
session_destroy();

// Te trimite înapoi la interfață (sau login.html, cum preferi)
header("Location: interfata.html");
exit;
?>