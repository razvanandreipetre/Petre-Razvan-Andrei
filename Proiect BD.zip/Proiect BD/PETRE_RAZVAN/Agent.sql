create table Agent
(
    id_agent int          not null
        primary key,
    id_user  int          not null,
    nume     varchar(100) not null,
    email    varchar(100) not null,
    telefon  bigint       not null,
    constraint Agent_ibfk_1
        foreign key (id_user) references User (id)
);

create index id_user
    on Agent (id_user);

