create table User
(
    id       int          not null
        primary key,
    username varchar(100) not null,
    parola   varchar(100) not null
);

