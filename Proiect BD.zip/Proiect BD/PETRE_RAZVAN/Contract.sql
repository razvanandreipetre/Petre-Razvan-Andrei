create table Contract
(
    id_contract      int   not null
        primary key,
    id_jucator       int   not null,
    id_club          int   not null,
    salariu          int   not null,
    data_start       date  not null,
    data_sfarsit     date  not null,
    clauza_reziliere float not null,
    constraint Contract_ibfk_1
        foreign key (id_jucator) references Jucatori (id_jucator),
    constraint Contract_ibfk_2
        foreign key (id_club) references Cluburi (id_club)
);

create index id_club
    on Contract (id_club);

create index id_jucator
    on Contract (id_jucator);

create index idx_salariu
    on Contract (salariu);

