create
    definer = root@`%` procedure PopuleazaTransferuri()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE club_actual INT;
    DECLARE club_dest INT;
    WHILE i <= 50 DO
        SET club_actual = FLOOR(1 + RAND() * 50);
        SET club_dest = FLOOR(1 + RAND() * 50);
        IF club_actual = club_dest THEN
            SET club_dest = (club_dest + 1) MOD 50;
            IF club_dest = 0 THEN SET club_dest = 1; END IF;
        END IF;

        INSERT INTO Transferuri (id_transfer, id_jucator, id_club_actual, id_club_destinatie, suma_transfer)
        VALUES (
            i,
            FLOOR(1 + RAND() * 50),
            club_actual,
            club_dest,
            ROUND(1 + RAND() * 100, 2)
        );
        SET i = i + 1;
    END WHILE;
END;

