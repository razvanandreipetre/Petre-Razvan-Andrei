create
    definer = root@`%` procedure adauga_document_confidential(IN p_id_jucator int, IN p_descriere varchar(100),
                                                              IN p_cnp varchar(20))
BEGIN
    INSERT INTO Documente (id_jucator, descriere, cnp)
    VALUES (
        p_id_jucator,
        p_descriere,
        AES_ENCRYPT(p_cnp, 'cheieCNP123')
    );
END;

