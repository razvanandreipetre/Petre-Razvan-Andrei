create
    definer = root@`%` procedure JucatoriDupaNationalitate(IN tara varchar(50))
BEGIN
    SELECT nume AS Nume_Jucator,data_nastere,pozitie,valoare_piata
    FROM Jucatori
    WHERE nationalitate = tara
    ORDER BY nume ASC;
END;

