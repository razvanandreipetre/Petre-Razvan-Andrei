create
    definer = root@`%` procedure PopuleazaCluburi()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE tara VARCHAR(50);
    WHILE i <= 50 DO
        SET tara = ELT(FLOOR(1 + RAND() * 5), 'Anglia', 'Italia', 'Spania', 'Franta', 'Germania');

        INSERT INTO Cluburi (id_club, nume, tara)
        VALUES (
            i,
            CONCAT('Club', i),
            tara
        );
        SET i = i + 1;
    END WHILE;
END;

