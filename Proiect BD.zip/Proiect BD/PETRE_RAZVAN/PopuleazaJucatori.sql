create
    definer = root@`%` procedure PopuleazaJucatori()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE pozitie VARCHAR(50);
    DECLARE tari VARCHAR(50);
    WHILE i <= 50 DO
        SET pozitie = ELT(FLOOR(1 + RAND() * 4), 'Portar', 'Fundas', 'Mijlocas', 'Atacant');
        SET tari = ELT(FLOOR(1 + RAND() * 10), 'Romania', 'Spania', 'Germania', 'Franta', 'Brazilia','Portugalia','Argentina','Anglia','Olanda','Italia');

        INSERT INTO Jucatori (id_jucator, nume, data_nastere, valoare_piata, varsta, pozitie, nationalitate)
        VALUES (
            i,
            CONCAT('Jucator', i),
            DATE_SUB(CURDATE(), INTERVAL (18 + FLOOR(RAND() * 15)) YEAR),
            ROUND(1 + (RAND() * 99), 2),
            FLOOR(18 + RAND() * 15),
            pozitie,
            tari
        );
        SET i = i + 1;
    END WHILE;
END;

