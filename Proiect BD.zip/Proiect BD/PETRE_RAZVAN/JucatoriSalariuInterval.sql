create
    definer = root@`%` procedure JucatoriSalariuInterval(IN salariu_minim int, IN salariu_maxim int)
BEGIN
    SELECT Jucatori.nume AS nume_Jucator,Contract.salariu AS salariu
    FROM Jucatori
    JOIN Contract ON Jucatori.id_jucator = Contract.id_jucator
    WHERE Contract.salariu BETWEEN salariu_minim AND salariu_maxim
    ORDER BY Contract.salariu ASC;
END;

