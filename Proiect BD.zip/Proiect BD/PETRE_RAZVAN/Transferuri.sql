create table Transferuri
(
    id_transfer        int   not null
        primary key,
    id_jucator         int   not null,
    id_club_actual     int   not null,
    id_club_destinatie int   not null,
    suma_transfer      float not null,
    constraint Transferuri_ibfk_1
        foreign key (id_jucator) references Jucatori (id_jucator),
    constraint Transferuri_ibfk_2
        foreign key (id_club_actual) references Cluburi (id_club),
    constraint Transferuri_ibfk_3
        foreign key (id_club_destinatie) references Cluburi (id_club)
);

create index id_club_actual
    on Transferuri (id_club_actual);

create index id_club_destinatie
    on Transferuri (id_club_destinatie);

create index id_jucator
    on Transferuri (id_jucator);

