create
    definer = root@`%` procedure PopuleazaContracte()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 50 DO
        INSERT INTO Contract (id_contract, id_jucator, id_club, salariu, data_start, data_sfarsit, clauza_reziliere)
        VALUES (
            i,
            i,
            FLOOR(1 + RAND() * 50),
            FLOOR(5000 + RAND() * 20000),
            CURDATE(),
            DATE_ADD(CURDATE(), INTERVAL FLOOR(1 + RAND() * 5) YEAR),
            ROUND(1 + RAND() * 10, 2)
        );
        SET i = i + 1;
    END WHILE;
END;

