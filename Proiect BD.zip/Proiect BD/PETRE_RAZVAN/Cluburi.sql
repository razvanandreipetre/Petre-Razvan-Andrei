create table Cluburi
(
    id_club int          not null
        primary key,
    nume    varchar(100) not null,
    tara    varchar(50)  not null
);

