create
    definer = root@`%` procedure PopuleazaUseri()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 50 DO
        INSERT INTO User (id, username, parola)
        VALUES (
            i,
            CONCAT('user', i),
            CONCAT('pass', i)
        );
        SET i = i + 1;
    END WHILE;
END;

