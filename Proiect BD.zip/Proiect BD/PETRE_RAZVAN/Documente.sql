create table Documente
(
    id_document int auto_increment
        primary key,
    id_jucator  int          not null,
    descriere   varchar(200) null,
    cnp         blob         null,
    constraint Documente_ibfk_1
        foreign key (id_jucator) references Jucatori (id_jucator)
);

create index id_jucator
    on Documente (id_jucator);

