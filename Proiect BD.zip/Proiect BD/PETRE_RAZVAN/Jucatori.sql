create table Jucatori
(
    id_jucator    int          not null
        primary key,
    nume          varchar(100) not null,
    data_nastere  date         not null,
    valoare_piata float        not null,
    varsta        int          not null,
    pozitie       varchar(50)  not null,
    nationalitate varchar(50)  not null
);

