create table user1
(
    id          int auto_increment
        primary key,
    username    varchar(50) not null,
    parola_hash char(64)    not null
);

