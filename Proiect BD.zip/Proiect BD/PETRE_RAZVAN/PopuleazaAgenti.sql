create
    definer = root@`%` procedure PopuleazaAgenti()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 50 DO
        INSERT INTO Agent (id_agent, id_user, nume, email, telefon)
        VALUES (
            i,
            i,
            CONCAT('Agent', i),
            CONCAT('agent', i, '@email.com'),
            FLOOR(700000000 + (RAND() * 99999999))
        );
        SET i = i + 1;
    END WHILE;
END;

