<?php
header('Content-Type: application/json');

// PHP: Validarea pe partea de server (Server-Side)
$response = ['success' => false, 'errors' => []];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nume = trim($_POST['nume'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mesaj = trim($_POST['mesaj'] ?? '');

    // 1. Validare Nume (minim 3 caractere)
    if (empty($nume) || strlen($nume) < 3) {
        $response['errors']['nume'] = "Numele este obligatoriu și trebuie să aibă minim 3 caractere.";
    }

    // 2. Validare Email (format valid)
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['errors']['email'] = "Adresa de email este obligatorie și trebuie să fie validă.";
    }

    // 3. Validare Mesaj (minim 10 caractere)
    if (empty($mesaj) || strlen($mesaj) < 10) {
        $response['errors']['mesaj'] = "Mesajul este obligatoriu și trebuie să aibă minim 10 caractere.";
    }
    
    // 4. Procesare finală
    if (empty($response['errors'])) {
        // Dacă nu există erori, putem procesa datele (trimite email, salvează în DB)
        
        $response['success'] = true;
        // Puteți adăuga un mesaj de succes pentru a fi citit de AJAX:
        $response['message'] = "Datele au fost procesate cu succes pe server. Vă mulțumim!";
    }
} else {
    $response['errors']['general'] = "Metodă de cerere invalidă.";
}

echo json_encode($response);
exit;
?>