document.getElementById('contactForm').addEventListener('submit', function(event) {
    // Oprim trimiterea formularului standard pentru a permite JS-ului să preia controlul
    event.preventDefault(); 
    
    const form = event.target;
    const numeInput = document.getElementById('nume');
    const emailInput = document.getElementById('email');
    const mesajInput = document.getElementById('mesaj');
    const successMessage = document.getElementById('js-success-message');
    
    let isValid = true;
    
    // Funcție pentru afișarea erorilor sub câmp
    function displayError(fieldId, message) {
        document.getElementById(`error-${fieldId}`).textContent = message;
        isValid = false;
    }
    
    // Funcție pentru ștergerea erorilor
    function clearError(fieldId) {
        document.getElementById(`error-${fieldId}`).textContent = '';
    }
    
    // 1. Resetare la fiecare submit
    successMessage.style.display = 'none';
    clearError('nume');
    clearError('email');
    clearError('mesaj');

    // --- 2. Validare Nume (minim 3 caractere) ---
    if (numeInput.value.length < 3) {
        displayError('nume', 'Numele trebuie să aibă minim 3 caractere.');
    }

    // --- 3. Validare Email (format) ---
    // Expresie regulată simplă pentru formatul email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailInput.value)) {
        displayError('email', 'Vă rugăm introduceți o adresă de email validă.');
    }

    // --- 4. Validare Mesaj (minim 10 caractere) ---
    if (mesajInput.value.length < 10) {
        displayError('mesaj', 'Mesajul trebuie să aibă minim 10 caractere.');
    }
    
    // 5. Afișarea rezultatului (Dacă totul este valid)
    if (isValid) {
        const nume = numeInput.value;
        const mesaj = mesajInput.value;
        
        // Afișează mesajul de mulțumire
        successMessage.innerHTML = `✅ Vă mulțumim, **${nume}**! Mesajul dumneavoastră a fost trimis: <br><br> <em>"${mesaj}"</em>`;
        successMessage.style.display = 'block';
        
        // Ascunde formularul
        form.style.display = 'none';

        // ATENȚIE: Aici ar trebui să folosiți Fetch API sau XMLHttpRequest
        // pentru a trimite datele asincron către process.php fără a reîncărca pagina.
    } 
});