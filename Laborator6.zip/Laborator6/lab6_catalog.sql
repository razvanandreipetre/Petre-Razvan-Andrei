create table lab6_catalog
(
    id    int auto_increment
        primary key,
    nume  varchar(100)  not null,
    an    int           not null,
    media decimal(4, 2) not null
);

INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (1, 'Popescu Andrei', 2, 8.50);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (2, 'Ionescu Elena', 1, 9.75);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (3, 'Dumitrescu Radu', 3, 7.20);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (4, 'Matei Alina', 4, 10.00);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (5, 'Stanciu Vlad', 1, 5.50);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (6, 'Constantin Diana', 2, 9.10);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (7, 'Popa Mihai', 3, 6.80);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (8, 'Gheorghe Ioana', 4, 8.90);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (9, 'Rusu Alex', 1, 7.45);
INSERT INTO studenti.lab6_catalog (id, nume, an, media) VALUES (10, 'Munteanu Cristina', 2, 9.30);
