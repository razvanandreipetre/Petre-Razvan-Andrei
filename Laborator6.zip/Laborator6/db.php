<?php
// Configurația conform docker-compose.yml-ul tău
$host = 'mysql';       // Numele serviciului (NU localhost)
$db   = 'studenti';    // Baza de date definita in yml
$user = 'user';        // User definit in yml
$pass = 'password';    // Parola definita in yml
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Răspundem cu JSON în caz de eroare pentru a nu strica frontend-ul
    echo json_encode(["error" => "Eroare conectare DB: " . $e->getMessage()]);
    exit;
}
?>