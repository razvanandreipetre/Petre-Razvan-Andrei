<?php
// Setăm header-ele pentru a spune browserului că trimitem JSON
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");

// Includem conexiunea la baza de date
require 'db.php';

// Verificăm metoda cererii (GET sau POST)
$method = $_SERVER['REQUEST_METHOD'];

// --- CAZ 1: Dacă primim GET, trimitem lista de studenți ---
if ($method === 'GET') {
    try {
        // Atenție: Folosim numele tabelului din SQL-ul tău: lab6_catalog
        $stmt = $pdo->query("SELECT * FROM lab6_catalog ORDER BY id DESC");
        $studenti = $stmt->fetchAll();
        
        echo json_encode($studenti);
    } catch (PDOException $e) {
        // Dacă tabelul nu există, returnăm o listă goală în loc de eroare fatală
        echo json_encode([]);
    }
}

// --- CAZ 2: Dacă primim POST, adăugăm un student ---
elseif ($method === 'POST') {
    // Citim datele JSON primite de la HTML
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['nume'], $data['an'], $data['media'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO lab6_catalog (nume, an, media) VALUES (:nume, :an, :media)");
            $stmt->execute([
                ':nume' => $data['nume'],
                ':an' => $data['an'],
                ':media' => $data['media']
            ]);
            echo json_encode(["mesaj" => "Student adăugat cu succes!"]);
        } catch (PDOException $e) {
            echo json_encode(["eroare" => "Eroare SQL: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(["eroare" => "Date incomplete"]);
    }
}
?>